figma.showUI(__html__, { width: 240, height: 196 });

function log(msg) {
  figma.ui.postMessage({ type: "log", message: msg });
}

// Les bytes sont fournis par l'UI; pas de décodage base64 côté plugin
const RATIOS = [
  { name: "1:1", ratio: 1 },
  { name: "4:3", ratio: 4 / 3 },
  { name: "16:9", ratio: 16 / 9 },
  { name: "20:9", ratio: 20 / 9 },
];

const ORIENTATIONS = ["landscape", "portrait"];

const RADIUS_VALUES = {
  square: 0,
  sm: 4,
  md: 8,
  lg: 16,
  xl: 24,
  "2xl": 32,
  rounded: 9999,
};

// Récupère les valeurs de radius depuis la collection ou utilise les valeurs par défaut
async function getRadiusVariables() {
  try {
    const collection = figma.variables
      .getLocalVariableCollections()
      .find((c) => c.name === "Style/Radius");

    if (!collection) {
      log(
        "⚠️ Collection Style/Radius non trouvée, utilisation des valeurs par défaut"
      );
      return RADIUS_VALUES;
    }

    const radiusVars = {};
    for (const id of collection.variableIds) {
      const variable = figma.variables.getVariableById(id);
      if (variable) {
        const value =
          variable.valuesByMode[Object.keys(variable.valuesByMode)[0]];
        radiusVars[variable.name] =
          typeof value === "number" ? value : RADIUS_VALUES[variable.name];
      }
    }
    return Object.keys(radiusVars).length > 0 ? radiusVars : RADIUS_VALUES;
  } catch (e) {
    log(`⚠️ Erreur lors de la lecture des variables: ${e.message}`);
    return RADIUS_VALUES;
  }
}

// Les dimensions des images sont fournies par l'UI (naturalWidth/naturalHeight)

figma.ui.onmessage = async (msg) => {
  if (msg.type !== "generate-images-components") return;

  try {
    const files = msg.files;
    if (!files.length) {
      log("❌ Aucune image chargée");
      return;
    }

    log(`📸 ${files.length} image(s) à traiter...`);

    // Créer une page dédiée
    let imagePage = figma.root.children.find(
      (page) => page.type === "PAGE" && page.name === "    ♢ Image"
    );
    if (!imagePage) {
      imagePage = figma.createPage();
      imagePage.name = "    ♢ Image";
      log(`📄 Page créée: "Image"`);
    }

    // Traiter les images et créer les composants galerie
    const imageComponents = [];
    let xOffset = 0;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      log(`🖼️ Traitement image ${i + 1}/${files.length}: ${file.name}`);

      try {
        // Obtenir les dimensions originales transmises par l'UI
        const origWidth = file.width;
        const origHeight = file.height;
        const ratio = origWidth / origHeight;

        // Redimensionner à 1920px width
        let newWidth = 1920;
        let newHeight = Math.round(newWidth / ratio);
        if (newHeight > 1080) {
          // Si dépasse 1080px height, redimensionner à 1080px height
          newHeight = 1080;
          newWidth = Math.round(newHeight * ratio);
        }

        // Créer un composant pour l'image
        const imageComponent = figma.createComponent();
        imageComponent.name = `image${i + 1}`;

        // Ajouter l'image en background du composant (cover + center)
        const bytes =
          file.bytes && file.bytes.length
            ? new Uint8Array(file.bytes)
            : new Uint8Array([]);
        const hash = figma.createImage(bytes).hash;
        imageComponent.fills = [
          { type: "IMAGE", imageHash: hash, scaleMode: "FILL" },
        ];
        // Redimensionner le composant aux dimensions calculées
        imageComponent.resize(newWidth, newHeight);
        imageComponent.clipsContent = true;
        // Ne pas activer l'autolayout sur le composant image pour conserver les dimensions du contenu

        imagePage.appendChild(imageComponent);
        imageComponent.x = xOffset;
        imageComponent.y = 0;
        xOffset += newWidth + 40;

        imageComponents.push({
          component: imageComponent,
          ratio,
          name: file.name,
        });
        log(
          `✅ Image ${
            i + 1
          } prête: orig=${origWidth}x${origHeight} → ${newWidth}x${newHeight}px, bytes=${
            file.bytes && file.bytes.length ? file.bytes.length : 0
          }`
        );
      } catch (e) {
        log(`❌ Erreur image ${i + 1}: ${e.message}`);
      }
    }

    if (imageComponents.length === 0) {
      log("❌ Aucune image n'a pu être traitée");
      return;
    }

    // Créer le ComponentSet galerie
    figma.currentPage = imagePage;
    imagePage.selection = imageComponents.map((ic) => ic.component);
    const imageComponentSet = figma.combineAsVariants(
      imageComponents.map((ic) => ic.component),
      imagePage
    );
    imageComponentSet.name = "_Image";
    imageComponentSet.layoutMode = "HORIZONTAL";
    imageComponentSet.layoutSizingHorizontal = "HUG";
    imageComponentSet.layoutSizingVertical = "HUG";
    imageComponentSet.itemSpacing = 20;
    imageComponentSet.paddingLeft = 40;
    imageComponentSet.paddingRight = 40;
    imageComponentSet.paddingTop = 40;
    imageComponentSet.paddingBottom = 40;

    log(`✅ Composant _Image créé avec ${imageComponents.length} images`);

    // Récupérer les valeurs de radius
    const radiusValues = await getRadiusVariables();
    const radiusKeys = Object.keys(radiusValues);

    // Créer les variantes format + radius
    log(`🔧 Création des variantes format + radius...`);
    const formatComponents = [];

    for (const ratioConfig of RATIOS) {
      const hasOrientation = ratioConfig.name !== "1:1";

      const orientationsToUse = hasOrientation ? ORIENTATIONS : ["false"];

      for (const orientation of orientationsToUse) {
        for (const radiusKey of radiusKeys) {
          const formatComponent = figma.createComponent();
          const radiusValue = radiusValues[radiusKey];

          // Nom de la variante
          const variantParts = [
            `ratio=${ratioConfig.name}`,
            `orientation=${orientation}`,
            `radius=${radiusKey}`,
          ];
          formatComponent.name = variantParts.join(", ");

          // Calculer les dimensions au plus proche des maxima 1920x1080
          let targetRatio = ratioConfig.ratio;
          if (orientation === "portrait") {
            targetRatio = 1 / targetRatio;
          }

          let width = 1920;
          let height = Math.floor(width / targetRatio);
          if (height > 1080) {
            height = 1080;
            width = Math.floor(height * targetRatio);
          }

          // Configurer le composant sans frame, avec coin arrondi
          formatComponent.resize(width, height);
          formatComponent.cornerRadius = radiusValue;

          // Préparer l'autolayout avant d'ajouter l'instance pour autoriser FILL
          formatComponent.layoutMode = "VERTICAL";

          // Ajouter directement une instance d'un composant de la galerie et la faire remplir
          const baseImageComponent = imageComponentSet.children[0];
          const imageInstance = baseImageComponent.createInstance();
          formatComponent.appendChild(imageInstance);
          // Exposer l'instance imbriquée pour remonter ses propriétés
          imageInstance.isExposedInstance = true;
          imageInstance.layoutSizingHorizontal = "FILL";
          imageInstance.layoutSizingVertical = "FILL";

          // Appliquer le clipping pour respecter le radius
          formatComponent.clipsContent = true;

          imagePage.appendChild(formatComponent);
          formatComponents.push(formatComponent);
        }
      }
    }

    log(`📦 ${formatComponents.length} composants variantes créés`);

    // Positionner les composants format en grille
    let gridX = 0,
      gridY = 0;
    const colsCount = 7;
    const spacing = 20;
    const cellSize = 100; // Taille approximative pour le positionnement

    for (let i = 0; i < formatComponents.length; i++) {
      const col = i % colsCount;
      const row = Math.floor(i / colsCount);
      formatComponents[i].x = gridX + col * (cellSize + spacing);
      formatComponents[i].y = gridY + row * (cellSize + spacing);
    }

    // Créer le ComponentSet format
    figma.currentPage = imagePage;
    imagePage.selection = formatComponents;
    const formatComponentSet = figma.combineAsVariants(
      formatComponents,
      imagePage
    );
    formatComponentSet.name = "<ImageFormat>";
    // Utiliser auto-layout horizontal avec wrap pour simuler une grille 7x7
    formatComponentSet.layoutMode = "HORIZONTAL";
    formatComponentSet.primaryAxisSizingMode = "AUTO";
    formatComponentSet.counterAxisSizingMode = "AUTO";
    formatComponentSet.itemSpacing = 20;
    formatComponentSet.paddingLeft = 40;
    formatComponentSet.paddingRight = 40;
    formatComponentSet.paddingTop = 40;
    formatComponentSet.paddingBottom = 40;

    log(
      `✅ ComponentSet <ImageFormat> créé avec ${formatComponents.length} variantes`
    );

    imagePage.selection = [imageComponentSet, formatComponentSet];
    figma.viewport.scrollAndZoomIntoView([
      imageComponentSet,
      formatComponentSet,
    ]);

    figma.closePlugin("✅ Variantes d'images générées avec succès.");
  } catch (e) {
    log(`❌ Erreur finale: ${e.message}`);
    log(`Stack: ${e.stack}`);
  }
};

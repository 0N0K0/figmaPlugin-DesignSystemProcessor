figma.showUI(__html__, { width: 240, height: 196 });

function log(msg) {
  figma.ui.postMessage({ type: "log", message: String(msg) });
}

// Utils: angle (deg) -> gradientTransform matrix
function angleToTransform(deg) {
  const rad = (deg * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  return [
    [cos, sin, 0],
    [-sin, cos, 0],
  ];
}

const DEFAULT_ANGLE_DEG = 135;

function normalizeName(name) {
  return name.toLowerCase().replace(/\s+/g, " ").trim();
}

function tokenizePath(name) {
  // split on common separators: / . > _ - space
  return normalizeName(name)
    .split(/[\/\._>\-\s]+/)
    .filter(Boolean);
}

function getColorFromVariable(variable, modeId) {
  const value = variable.valuesByMode?.[modeId];
  if (!value) return null;
  // value is an RGBA
  return { r: value.r, g: value.g, b: value.b, a: value.a ?? 1 };
}

function colorToStop(color, position) {
  return { position, color };
}

function upsertPaintStyle(name, stops, angleDeg) {
  const existing = figma.getLocalPaintStyles().find((s) => s.name === name);
  const paints = [
    {
      type: "GRADIENT_LINEAR",
      gradientStops: stops,
      gradientTransform: angleToTransform(angleDeg),
      visible: true,
      opacity: 1,
      blendMode: "NORMAL",
    },
  ];
  if (existing) {
    existing.paints = paints;
    return existing;
  }
  const style = figma.createPaintStyle();
  style.name = name;
  style.paints = paints;
  return style;
}

function findPaletteCollectionByName(name) {
  if (!figma.variables) return null;
  const cols = figma.variables.getLocalVariableCollections();
  return cols.find((c) => c.name === name) || null;
}

function indexVariablesByBrand(collection) {
  const varIds = collection.variableIds;
  const all = figma.variables.getLocalVariables();
  const inCollection = all.filter((v) => varIds.includes(v.id));

  // Build index: brand -> family -> shade -> variable
  const index = { brand: {} };
  for (const v of inCollection) {
    if (v.resolvedType !== "COLOR") continue;
    const tokens = tokenizePath(v.name);
    // Expect path containing brand and a family token (primary|secondary|accent) and a numeric shade
    const brandIdx = tokens.indexOf("brand");
    if (brandIdx === -1) continue;

    const families = ["primary", "secondary", "accent"];
    const fam = families.find((f) => tokens.includes(f));
    if (!fam) continue;

    // Find first numeric token that looks like a shade level
    const shadeTok = tokens.find((t) => /^\d{2,3}$/.test(t));
    if (!shadeTok) continue;

    const shade = shadeTok;
    if (!index.brand[fam]) index.brand[fam] = {};
    index.brand[fam][shade] = v;
  }
  return index;
}

function pickModeId(collection) {
  // Prefer a mode named "Base" or first one
  const base = collection.modes.find((m) => /base|light|default/i.test(m.name));
  return (base || collection.modes[0])?.modeId;
}

async function generateGradients() {
  if (!figma.variables) {
    log("❌ Variables API indisponible dans ce fichier.");
    return;
  }

  const collectionName = "Style/Colors/Palette";
  const col = findPaletteCollectionByName(collectionName);
  if (!col) {
    log(`❌ Collection introuvable: ${collectionName}`);
    return;
  }
  const modeId = pickModeId(col);
  if (!modeId) {
    log("❌ Aucun mode trouvé dans la collection de variables.");
    return;
  }

  const idx = indexVariablesByBrand(col);
  const families = ["primary", "secondary", "accent"];
  const needShades = ["200", "300", "400", "500", "600", "700", "800"];

  // Guard: report missing shades
  for (const fam of families) {
    for (const s of needShades) {
      if (!idx.brand?.[fam]?.[s]) {
        // Not fatal; we will skip affected gradients
        log(`⚠️ Manque ${fam}.${s}`);
      }
    }
  }

  const makeColor = (fam, shade) => {
    const v = idx.brand?.[fam]?.[shade];
    return v ? getColorFromVariable(v, modeId) : null;
  };

  const created = [];

  // Per-family gradients
  for (const fam of families) {
    // Depth: 200 -> 800
    const c200 = makeColor(fam, "200");
    const c800 = makeColor(fam, "800");
    if (c200 && c800) {
      const name = `Gradients/Brand/${capitalize(fam)}/Depth 200→800`;
      upsertPaintStyle(
        name,
        [colorToStop(c200, 0), colorToStop(c800, 1)],
        DEFAULT_ANGLE_DEG
      );
      created.push(name);
    }

    // Relief: 300 -> 500 -> 700
    const c300 = makeColor(fam, "300");
    const c500 = makeColor(fam, "500");
    const c700 = makeColor(fam, "700");
    if (c300 && c500 && c700) {
      const name = `Gradients/Brand/${capitalize(fam)}/Relief 300→500→700`;
      upsertPaintStyle(
        name,
        [colorToStop(c300, 0), colorToStop(c500, 0.5), colorToStop(c700, 1)],
        DEFAULT_ANGLE_DEG
      );
      created.push(name);
    }
  }

  // Pairwise family combinations
  const pairs = [
    ["primary", "secondary"],
    ["primary", "accent"],
    ["secondary", "accent"],
  ];

  for (const [a, b] of pairs) {
    const a500 = makeColor(a, "500");
    const b500 = makeColor(b, "500");
    if (a500 && b500) {
      const name = `Gradients/Brand/${capitalize(a)}×${capitalize(b)}/500→500`;
      upsertPaintStyle(
        name,
        [colorToStop(a500, 0), colorToStop(b500, 1)],
        DEFAULT_ANGLE_DEG
      );
      created.push(name);
    }
    const a600 = makeColor(a, "600");
    const b400 = makeColor(b, "400");
    if (a600 && b400) {
      const name = `Gradients/Brand/${capitalize(a)}×${capitalize(b)}/600→400`;
      upsertPaintStyle(
        name,
        [colorToStop(a600, 0), colorToStop(b400, 1)],
        DEFAULT_ANGLE_DEG
      );
      created.push(name);
    }
  }

  // Triple combination: primary.600 -> secondary.500 -> accent.400
  const p600 = makeColor("primary", "600");
  const s500 = makeColor("secondary", "500");
  const a400 = makeColor("accent", "400");
  if (p600 && s500 && a400) {
    const name = `Gradients/Brand/Primary×Secondary×Accent/600→500→400`;
    upsertPaintStyle(
      name,
      [colorToStop(p600, 0), colorToStop(s500, 0.5), colorToStop(a400, 1)],
      DEFAULT_ANGLE_DEG
    );
    created.push(name);
  }

  if (created.length) {
    log(`✅ ${created.length} gradients créés/mis à jour.`);
  } else {
    log("ℹ️ Aucun gradient créé (teintes manquantes ?)");
  }
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

figma.ui.onmessage = async (msg) => {
  if (msg.type !== "generate-styles") return;
  await generateGradients();
  figma.closePlugin("✅ Styles générés avec succès.");
};
